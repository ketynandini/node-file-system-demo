const fs = require("fs");

const content = `Hello, im Nandini 
This file was created using the fs module.
Date: ${new Date().toLocaleString()}`;

if (fs.existsSync("message.txt")) {
  console.log("File already exists! Overwriting...");
}

fs.writeFile("message.txt", content, (err) => {
  if (err) {
    if (err.code === "EACCES") {
      console.error("Permission denied — cannot write file.");
    } else if (err.code === "ENOENT") {
      console.error("Directory not found.");
    } else {
      console.error("Error writing file:", err.message);
    }
  } else {
    console.log("message.txt created successfully!");
    console.log("Content written:", content);
  }
});
